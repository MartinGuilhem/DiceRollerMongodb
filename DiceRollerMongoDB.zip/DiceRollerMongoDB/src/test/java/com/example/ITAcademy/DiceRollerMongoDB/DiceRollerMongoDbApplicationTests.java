package com.example.ITAcademy.DiceRollerMongoDB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiceRollerMongoDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
